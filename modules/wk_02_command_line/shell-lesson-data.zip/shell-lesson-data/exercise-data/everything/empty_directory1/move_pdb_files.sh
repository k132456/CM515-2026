#!/bin/bash

found_pdb=false

for pdb in *.pdb; do
  # If no .pdb files exist, the glob stays literal
  [ -e "$pdb" ] || continue

  found_pdb=true

  # Remove .pdb extension to get directory name
  dir="${pdb%.pdb}"

  # Create directory if it doesn't exist
  mkdir -p "$dir"

  # Move the pdb file into the directory
  mv "$pdb" "$dir/"
done

if [ "$found_pdb" = true ]; then
  echo "All PDB files added to new directories."
else
  echo "No PDB files detected."
fi
